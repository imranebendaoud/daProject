declare module "@salesforce/resourceUrl/Adversaire" {
    var Adversaire: string;
    export default Adversaire;
}