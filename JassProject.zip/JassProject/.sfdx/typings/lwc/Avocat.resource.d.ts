declare module "@salesforce/resourceUrl/Avocat" {
    var Avocat: string;
    export default Avocat;
}