declare module "@salesforce/resourceUrl/Expert" {
    var Expert: string;
    export default Expert;
}