declare module "@salesforce/resourceUrl/Victime" {
    var Victime: string;
    export default Victime;
}